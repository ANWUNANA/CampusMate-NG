# CampusMate NG — Supabase Auth Build

This build connects the CampusMate NG front end to Supabase Auth and the CampusMate PostgreSQL database.

## Setup
1. Run `CampusMate_NG_Auth_Patch.sql` in Supabase SQL Editor after the original schema has succeeded.
2. Upload `index.html` to the GitHub repository.
3. The browser build uses the Supabase Project URL and Publishable Key in the script configuration.
4. In Supabase Auth, email/password authentication should be enabled (the default).

## Important
- The browser uses the **publishable** key only.
- Never put a Supabase `sb_secret_...` or `service_role` key in this file.
- The starter academic records are demo records intended to make the first build testable; replace them with approved university data.
