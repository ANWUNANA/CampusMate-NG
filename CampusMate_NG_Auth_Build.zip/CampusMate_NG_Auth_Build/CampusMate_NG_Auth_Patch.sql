-- CampusMate NG — Supabase Auth + security patch
-- Run this AFTER the main CampusMate NG schema has already succeeded.

-- 1) Automatically create a student profile whenever a Supabase Auth user is created.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    'student'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- 2) Prevent ordinary users from changing their own role to admin/tutor/etc.
create or replace function public.prevent_non_admin_role_change()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  if old.role is distinct from new.role
     and not exists (
       select 1 from public.profiles p
       where p.id = auth.uid() and p.role = 'admin'
     ) then
    new.role := old.role;
  end if;
  return new;
end;
$$;

drop trigger if exists protect_profile_role on public.profiles;
create trigger protect_profile_role
before update on public.profiles
for each row execute procedure public.prevent_non_admin_role_change();

-- 3) Public academic catalogue: authenticated users may read the structure.
alter table public.universities enable row level security;
alter table public.faculties enable row level security;
alter table public.departments enable row level security;
alter table public.programmes enable row level security;
alter table public.levels enable row level security;
alter table public.semesters enable row level security;
alter table public.courses enable row level security;
alter table public.programme_courses enable row level security;

drop policy if exists "authenticated read universities" on public.universities;
create policy "authenticated read universities"
on public.universities for select to authenticated using (true);

drop policy if exists "authenticated read faculties" on public.faculties;
create policy "authenticated read faculties"
on public.faculties for select to authenticated using (true);

drop policy if exists "authenticated read departments" on public.departments;
create policy "authenticated read departments"
on public.departments for select to authenticated using (true);

drop policy if exists "authenticated read programmes" on public.programmes;
create policy "authenticated read programmes"
on public.programmes for select to authenticated using (true);

drop policy if exists "authenticated read levels" on public.levels;
create policy "authenticated read levels"
on public.levels for select to authenticated using (true);

drop policy if exists "authenticated read semesters" on public.semesters;
create policy "authenticated read semesters"
on public.semesters for select to authenticated using (true);

drop policy if exists "authenticated read courses" on public.courses;
create policy "authenticated read courses"
on public.courses for select to authenticated using (true);

drop policy if exists "authenticated read programme_courses" on public.programme_courses;
create policy "authenticated read programme_courses"
on public.programme_courses for select to authenticated using (true);

-- 4) Published learning content is readable by signed-in students.
alter table public.topics enable row level security;
alter table public.learning_materials enable row level security;
alter table public.quizzes enable row level security;
alter table public.quiz_questions enable row level security;
alter table public.announcements enable row level security;

drop policy if exists "authenticated read published topics" on public.topics;
create policy "authenticated read published topics"
on public.topics for select to authenticated
using (status = 'published');

drop policy if exists "authenticated read published materials" on public.learning_materials;
create policy "authenticated read published materials"
on public.learning_materials for select to authenticated
using (status = 'published');

drop policy if exists "authenticated read published quizzes" on public.quizzes;
create policy "authenticated read published quizzes"
on public.quizzes for select to authenticated
using (status = 'published');

drop policy if exists "authenticated read quiz questions" on public.quiz_questions;
create policy "authenticated read quiz questions"
on public.quiz_questions for select to authenticated
using (exists (select 1 from public.quizzes q where q.id = quiz_id and q.status = 'published'));

drop policy if exists "authenticated read published announcements" on public.announcements;
create policy "authenticated read published announcements"
on public.announcements for select to authenticated
using (published = true);

-- 5) Allow an authenticated student to insert/update only their own profile row.
drop policy if exists "insert own profile" on public.profiles;
create policy "insert own profile"
on public.profiles for insert to authenticated
with check (id = auth.uid());

-- Note: admin-only write policies for academic content will be added in the Admin phase.

-- 6) Small starter dataset so the first authenticated build is immediately testable.
-- These are starter records; replace/extend them with the university's official catalogue.
do $$
declare
  u uuid;
  f uuid;
  d uuid;
  p uuid;
  l uuid;
  s uuid;
  c uuid;
  t uuid;
  q uuid;
begin
  select id into u from public.universities where short_name = 'TSU' limit 1;
  if u is null then
    insert into public.universities(name, short_name) values ('Taraba State University','TSU') returning id into u;
  end if;

  insert into public.faculties(university_id,name) values (u,'Faculty of Health Sciences')
  on conflict (university_id,name) do update set name=excluded.name returning id into f;
  select id into f from public.faculties where university_id=u and name='Faculty of Health Sciences';

  insert into public.departments(faculty_id,name) values (f,'Department of Nursing Science')
  on conflict (faculty_id,name) do update set name=excluded.name returning id into d;
  select id into d from public.departments where faculty_id=f and name='Department of Nursing Science';

  insert into public.programmes(department_id,name,short_name) values (d,'Nursing Science','NUR')
  on conflict (department_id,name) do update set short_name=excluded.short_name returning id into p;
  select id into p from public.programmes where department_id=d and name='Nursing Science';

  insert into public.levels(programme_id,name,level_number) values
    (p,'100L',100),(p,'200L',200),(p,'300L',300),(p,'400L',400),(p,'500L',500)
  on conflict (programme_id,level_number) do nothing;
  select id into l from public.levels where programme_id=p and level_number=200;

  insert into public.semesters(programme_id,name,academic_session,is_current) values
    (p,'First Semester','2026/2027',false),(p,'Second Semester','2026/2027',true)
  on conflict do nothing;
  select id into s from public.semesters where programme_id=p and name='Second Semester' limit 1;

  insert into public.courses(code,name,description,credit_units) values
    ('BCH 202','Biochemistry','Fundamental knowledge of biochemical processes, biomolecules and metabolism.',3),
    ('ANA 204','Human Anatomy','Structure and organization of the human body.',3),
    ('PHS 202','Physiology','Normal functions of cells, tissues, organs and body systems.',3),
    ('NUR 201','Fundamentals of Nursing','Core principles and routine practices of professional nursing.',2),
    ('PHC 203','Community Health','Principles of health promotion, prevention and community-based care.',2)
  on conflict(code) do update set name=excluded.name, description=excluded.description, credit_units=excluded.credit_units;

  for c in select id from public.courses where code in ('BCH 202','ANA 204','PHS 202','NUR 201','PHC 203') loop
    insert into public.programme_courses(programme_id,level_id,semester_id,course_id,is_core)
    values(p,l,s,c,true)
    on conflict do nothing;
  end loop;

  select id into c from public.courses where code='BCH 202';
  insert into public.topics(course_id,title,description,sort_order,status) values
    (c,'Cellular Chemistry','Chemical foundations of cellular processes.',1,'published'),
    (c,'Proteins & Amino Acids','Protein structure and amino acid fundamentals.',2,'published'),
    (c,'Carbohydrates','Major carbohydrate classes and metabolism.',3,'published'),
    (c,'Lipids','Structure, functions and clinical relevance of lipids.',4,'published')
  on conflict do nothing;

  for t in select id from public.topics where course_id=c loop
    insert into public.learning_materials(topic_id,title,content,material_type,status)
    values(t,'Study Note','Starter learning material for CampusMate NG. Replace this with the approved departmental note.','note','published')
    on conflict do nothing;
  end loop;

  insert into public.quizzes(course_id,title,description,time_limit_minutes,status)
  values(c,'Biochemistry Quick Quiz','Starter practice quiz.',5,'published')
  on conflict do nothing;
  select id into q from public.quizzes where course_id=c and title='Biochemistry Quick Quiz' limit 1;

  insert into public.quiz_questions(quiz_id,question_text,options,correct_option,explanation,marks)
  values
    (q,'The major solvent in most cells is?','["Protein","Water","Lipid","DNA"]'::jsonb,1,'Water is the major solvent in cells.',1),
    (q,'Most enzymes are?','["Proteins","Carbohydrates","Minerals","Vitamins"]'::jsonb,0,'Most enzymes are proteins.',1),
    (q,'Which is a lipid?','["Glucose","Glycine","Cholesterol","Glycogen"]'::jsonb,2,'Cholesterol is a lipid.',1),
    (q,'Amino acids are building blocks of?','["Proteins","Lipids","Water","Minerals"]'::jsonb,0,'Amino acids form proteins.',1),
    (q,'Glycogen is mainly a storage form of?','["Protein","Carbohydrate","Lipid","Vitamin"]'::jsonb,1,'Glycogen is a storage polysaccharide.',1)
  on conflict do nothing;
end $$;
